# Установка и обновление библиотек

## Проблема с Python 3.13

Если вы видите ошибку:
```
AttributeError: 'Updater' object has no attribute '_Updater__polling_cleanup_cb'
```

Это означает, что версия `python-telegram-bot` несовместима с Python 3.13.

## Решение

### Вариант 1: Обновить библиотеку (рекомендуется)

```bash
pip install --upgrade python-telegram-bot>=21.5
```

Если система требует виртуальное окружение:

```bash
python3 -m venv venv
source venv/bin/activate
pip install --upgrade python-telegram-bot>=21.5
```

### Вариант 2: Использовать Python 3.11 или 3.12

Если обновление библиотеки невозможно, используйте Python 3.11 или 3.12:

```bash
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### Вариант 3: Использовать системный пакет (если доступен)

```bash
sudo apt install python3-telegram-bot
```

## Проверка версии

После установки проверьте версию:

```bash
python3 -c "import telegram; print(telegram.__version__)"
```

Должна быть версия 21.0 или выше для Python 3.13.

